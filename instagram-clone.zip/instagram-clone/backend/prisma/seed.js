// Seeds the database with a couple of demo users and posts.
// Run with: npm run seed (after migrations)
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const password = await bcrypt.hash('password123', 10);

  const alice = await prisma.user.upsert({
    where: { email: '[email protected]' },
    update: {},
    create: {
      username: 'alice',
      email: '[email protected]',
      password,
      fullName: 'Alice Johnson',
      bio: 'Photographer & traveler 📸',
    },
  });

  const bob = await prisma.user.upsert({
    where: { email: '[email protected]' },
    update: {},
    create: {
      username: 'bob',
      email: '[email protected]',
      password,
      fullName: 'Bob Smith',
      bio: 'Coffee enthusiast ☕',
    },
  });

  await prisma.follow.upsert({
    where: { followerId_followingId: { followerId: bob.id, followingId: alice.id } },
    update: {},
    create: { followerId: bob.id, followingId: alice.id },
  });

  console.log('Seed complete. Demo accounts:');
  console.log('  alice / password123');
  console.log('  bob   / password123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
