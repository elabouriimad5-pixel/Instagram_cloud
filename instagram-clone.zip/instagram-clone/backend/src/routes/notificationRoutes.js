const express = require('express');
const { authenticate } = require('../middleware/auth');
const { getNotifications, markAllAsRead, getUnreadCount } = require('../controllers/notificationController');

const router = express.Router();

router.get('/', authenticate, getNotifications);
router.get('/unread-count', authenticate, getUnreadCount);
router.put('/read', authenticate, markAllAsRead);

module.exports = router;
