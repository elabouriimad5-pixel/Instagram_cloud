const express = require('express');
const { body } = require('express-validator');
const { authenticate, optionalAuthenticate } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const validate = require('../middleware/validate');
const {
  getProfile,
  updateProfile,
  changePassword,
  searchUsers,
  followUser,
  unfollowUser,
  getFollowers,
  getFollowing,
} = require('../controllers/userController');

const router = express.Router();

router.get('/search', searchUsers);

router.put(
  '/me',
  authenticate,
  upload.single('avatar'),
  [
    body('fullName').optional().trim().isLength({ max: 100 }),
    body('bio').optional().trim().isLength({ max: 250 }),
  ],
  validate,
  updateProfile
);

router.put(
  '/me/password',
  authenticate,
  [
    body('currentPassword').notEmpty(),
    body('newPassword').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  ],
  validate,
  changePassword
);

router.get('/:username', optionalAuthenticate, getProfile);
router.get('/:username/followers', getFollowers);
router.get('/:username/following', getFollowing);
router.post('/:username/follow', authenticate, followUser);
router.delete('/:username/follow', authenticate, unfollowUser);

module.exports = router;
