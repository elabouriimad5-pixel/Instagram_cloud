const express = require('express');
const { body } = require('express-validator');
const { authenticate, optionalAuthenticate } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const validate = require('../middleware/validate');
const {
  createPost,
  getFeed,
  explorePosts,
  getUserPosts,
  getPost,
  deletePost,
  likePost,
  unlikePost,
  getComments,
  addComment,
  deleteComment,
} = require('../controllers/postController');

const router = express.Router();

router.get('/feed', authenticate, getFeed);
router.get('/explore', optionalAuthenticate, explorePosts);
router.get('/user/:username', optionalAuthenticate, getUserPosts);

router.post(
  '/',
  authenticate,
  upload.single('media'),
  [body('caption').optional().trim().isLength({ max: 2200 })],
  validate,
  createPost
);

router.get('/:id', optionalAuthenticate, getPost);
router.delete('/:id', authenticate, deletePost);

router.post('/:id/like', authenticate, likePost);
router.delete('/:id/like', authenticate, unlikePost);

router.get('/:id/comments', getComments);
router.post(
  '/:id/comments',
  authenticate,
  [body('text').trim().notEmpty().isLength({ max: 500 }).withMessage('Comment cannot be empty')],
  validate,
  addComment
);
router.delete('/:postId/comments/:commentId', authenticate, deleteComment);

module.exports = router;
