const express = require('express');
const { body } = require('express-validator');
const { authenticate } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { getConversations, getThread, sendMessage } = require('../controllers/messageController');

const router = express.Router();

router.get('/conversations', authenticate, getConversations);
router.get('/:username', authenticate, getThread);
router.post(
  '/:username',
  authenticate,
  [body('content').trim().notEmpty().isLength({ max: 2000 }).withMessage('Message cannot be empty')],
  validate,
  sendMessage
);

module.exports = router;
