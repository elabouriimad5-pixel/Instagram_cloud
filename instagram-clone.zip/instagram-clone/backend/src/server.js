require('dotenv').config();
const http = require('http');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const app = require('./app');

const PORT = process.env.PORT || 5000;

const server = http.createServer(app);

// --- Socket.IO setup for real-time messaging & notifications ---
const io = new Server(server, {
  cors: { origin: process.env.CLIENT_URL || '*' },
});

// Authenticate socket connections using the same JWT used for the REST API
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Authentication error'));
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    socket.user = payload;
    next();
  } catch (err) {
    next(new Error('Authentication error'));
  }
});

io.on('connection', (socket) => {
  // Each user joins a private room keyed by their user id.
  // Controllers emit to `user:<id>` to push real-time updates.
  socket.join(`user:${socket.user.id}`);

  socket.on('disconnect', () => {
    // no-op: room membership is cleaned up automatically
  });
});

// Make io accessible from controllers via req.app.get('io')
app.set('io', io);

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
