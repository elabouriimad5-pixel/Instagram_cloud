const prisma = require('../config/prisma');
const bcrypt = require('bcryptjs');

const PROFILE_SELECT = {
  id: true,
  username: true,
  fullName: true,
  bio: true,
  avatarUrl: true,
  isPrivate: true,
  createdAt: true,
};

// GET /api/users/:username
async function getProfile(req, res, next) {
  try {
    const { username } = req.params;

    const user = await prisma.user.findUnique({
      where: { username },
      select: {
        ...PROFILE_SELECT,
        _count: { select: { posts: true, followers: true, following: true } },
      },
    });

    if (!user) return res.status(404).json({ message: 'User not found' });

    let isFollowing = false;
    if (req.user) {
      const follow = await prisma.follow.findUnique({
        where: { followerId_followingId: { followerId: req.user.id, followingId: user.id } },
      });
      isFollowing = !!follow;
    }

    res.json({ ...user, isFollowing });
  } catch (err) {
    next(err);
  }
}

// PUT /api/users/me
async function updateProfile(req, res, next) {
  try {
    const { fullName, bio, isPrivate } = req.body;
    const data = {};
    if (fullName !== undefined) data.fullName = fullName;
    if (bio !== undefined) data.bio = bio;
    if (isPrivate !== undefined) data.isPrivate = isPrivate === 'true' || isPrivate === true;

    if (req.file) {
      data.avatarUrl = `/uploads/${req.file.filename}`;
    }

    const user = await prisma.user.update({
      where: { id: req.user.id },
      data,
      select: PROFILE_SELECT,
    });

    res.json({ user });
  } catch (err) {
    next(err);
  }
}

// PUT /api/users/me/password
async function changePassword(req, res, next) {
  try {
    const { currentPassword, newPassword } = req.body;

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    const valid = await bcrypt.compare(currentPassword, user.password);
    if (!valid) return res.status(400).json({ message: 'Current password is incorrect' });

    const hashed = await bcrypt.hash(newPassword, 10);
    await prisma.user.update({ where: { id: user.id }, data: { password: hashed } });

    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    next(err);
  }
}

// GET /api/users/search?q=
async function searchUsers(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ users: [] });

    const users = await prisma.user.findMany({
      where: {
        OR: [
          { username: { contains: q, mode: 'insensitive' } },
          { fullName: { contains: q, mode: 'insensitive' } },
        ],
      },
      select: { id: true, username: true, fullName: true, avatarUrl: true },
      take: 20,
    });

    res.json({ users });
  } catch (err) {
    next(err);
  }
}

// POST /api/users/:username/follow
async function followUser(req, res, next) {
  try {
    const target = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!target) return res.status(404).json({ message: 'User not found' });
    if (target.id === req.user.id) {
      return res.status(400).json({ message: 'You cannot follow yourself' });
    }

    await prisma.follow.create({
      data: { followerId: req.user.id, followingId: target.id },
    });

    await prisma.notification.create({
      data: { type: 'FOLLOW', recipientId: target.id, actorId: req.user.id },
    });

    res.status(201).json({ message: 'Followed successfully' });
  } catch (err) {
    if (err.code === 'P2002') {
      return res.status(409).json({ message: 'Already following this user' });
    }
    next(err);
  }
}

// DELETE /api/users/:username/follow
async function unfollowUser(req, res, next) {
  try {
    const target = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!target) return res.status(404).json({ message: 'User not found' });

    await prisma.follow.delete({
      where: { followerId_followingId: { followerId: req.user.id, followingId: target.id } },
    });

    res.json({ message: 'Unfollowed successfully' });
  } catch (err) {
    if (err.code === 'P2025') {
      return res.status(404).json({ message: 'You are not following this user' });
    }
    next(err);
  }
}

// GET /api/users/:username/followers
async function getFollowers(req, res, next) {
  try {
    const user = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const followers = await prisma.follow.findMany({
      where: { followingId: user.id },
      include: { follower: { select: { id: true, username: true, fullName: true, avatarUrl: true } } },
    });

    res.json({ followers: followers.map((f) => f.follower) });
  } catch (err) {
    next(err);
  }
}

// GET /api/users/:username/following
async function getFollowing(req, res, next) {
  try {
    const user = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const following = await prisma.follow.findMany({
      where: { followerId: user.id },
      include: { following: { select: { id: true, username: true, fullName: true, avatarUrl: true } } },
    });

    res.json({ following: following.map((f) => f.following) });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getProfile,
  updateProfile,
  changePassword,
  searchUsers,
  followUser,
  unfollowUser,
  getFollowers,
  getFollowing,
};
