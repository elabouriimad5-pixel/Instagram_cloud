const prisma = require('../config/prisma');

const USER_SELECT = { id: true, username: true, avatarUrl: true, fullName: true };

// GET /api/messages/conversations
// Returns a list of users the current user has exchanged messages with,
// along with the most recent message and unread count.
async function getConversations(req, res, next) {
  try {
    const userId = req.user.id;

    const messages = await prisma.message.findMany({
      where: { OR: [{ senderId: userId }, { receiverId: userId }] },
      orderBy: { createdAt: 'desc' },
      include: {
        sender: { select: USER_SELECT },
        receiver: { select: USER_SELECT },
      },
    });

    const conversations = new Map();

    for (const msg of messages) {
      const other = msg.senderId === userId ? msg.receiver : msg.sender;
      if (!conversations.has(other.id)) {
        conversations.set(other.id, {
          user: other,
          lastMessage: { content: msg.content, createdAt: msg.createdAt, senderId: msg.senderId },
          unreadCount: 0,
        });
      }
      if (msg.receiverId === userId && !msg.read) {
        conversations.get(other.id).unreadCount += 1;
      }
    }

    res.json({ conversations: Array.from(conversations.values()) });
  } catch (err) {
    next(err);
  }
}

// GET /api/messages/:username
async function getThread(req, res, next) {
  try {
    const otherUser = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!otherUser) return res.status(404).json({ message: 'User not found' });

    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: req.user.id, receiverId: otherUser.id },
          { senderId: otherUser.id, receiverId: req.user.id },
        ],
      },
      orderBy: { createdAt: 'asc' },
    });

    // Mark incoming messages as read
    await prisma.message.updateMany({
      where: { senderId: otherUser.id, receiverId: req.user.id, read: false },
      data: { read: true },
    });

    res.json({ messages, otherUser: { id: otherUser.id, username: otherUser.username, avatarUrl: otherUser.avatarUrl, fullName: otherUser.fullName } });
  } catch (err) {
    next(err);
  }
}

// POST /api/messages/:username
async function sendMessage(req, res, next) {
  try {
    const { content } = req.body;
    const receiver = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!receiver) return res.status(404).json({ message: 'User not found' });
    if (receiver.id === req.user.id) {
      return res.status(400).json({ message: 'Cannot message yourself' });
    }

    const message = await prisma.message.create({
      data: { content, senderId: req.user.id, receiverId: receiver.id },
    });

    await prisma.notification.create({
      data: { type: 'MESSAGE', recipientId: receiver.id, actorId: req.user.id },
    });

    // Emit real-time event via Socket.IO if available
    const io = req.app.get('io');
    if (io) {
      io.to(`user:${receiver.id}`).emit('new_message', message);
    }

    res.status(201).json({ message });
  } catch (err) {
    next(err);
  }
}

module.exports = { getConversations, getThread, sendMessage };
