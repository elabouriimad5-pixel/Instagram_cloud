const prisma = require('../config/prisma');

const ACTOR_SELECT = { id: true, username: true, avatarUrl: true, fullName: true };

// GET /api/notifications
async function getNotifications(req, res, next) {
  try {
    const notifications = await prisma.notification.findMany({
      where: { recipientId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: {
        actor: { select: ACTOR_SELECT },
        post: { select: { id: true, mediaUrl: true } },
      },
    });
    res.json({ notifications });
  } catch (err) {
    next(err);
  }
}

// PUT /api/notifications/read
// Marks all of the current user's notifications as read.
async function markAllAsRead(req, res, next) {
  try {
    await prisma.notification.updateMany({
      where: { recipientId: req.user.id, read: false },
      data: { read: true },
    });
    res.json({ message: 'Notifications marked as read' });
  } catch (err) {
    next(err);
  }
}

// GET /api/notifications/unread-count
async function getUnreadCount(req, res, next) {
  try {
    const count = await prisma.notification.count({
      where: { recipientId: req.user.id, read: false },
    });
    res.json({ count });
  } catch (err) {
    next(err);
  }
}

module.exports = { getNotifications, markAllAsRead, getUnreadCount };
