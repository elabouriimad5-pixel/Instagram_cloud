const prisma = require('../config/prisma');

const AUTHOR_SELECT = { id: true, username: true, avatarUrl: true, fullName: true };

function shapePost(post, userId) {
  return {
    id: post.id,
    caption: post.caption,
    mediaUrl: post.mediaUrl,
    mediaType: post.mediaType,
    createdAt: post.createdAt,
    author: post.author,
    likeCount: post._count?.likes ?? 0,
    commentCount: post._count?.comments ?? 0,
    likedByMe: userId ? post.likes?.some((l) => l.userId === userId) : false,
  };
}

// POST /api/posts
async function createPost(req, res, next) {
  try {
    if (!req.file) return res.status(400).json({ message: 'Media file is required' });

    const { caption } = req.body;
    const mediaType = req.file.mimetype.startsWith('video') ? 'VIDEO' : 'IMAGE';

    const post = await prisma.post.create({
      data: {
        caption,
        mediaUrl: `/uploads/${req.file.filename}`,
        mediaType,
        authorId: req.user.id,
      },
      include: { author: { select: AUTHOR_SELECT }, _count: { select: { likes: true, comments: true } } },
    });

    res.status(201).json({ post: shapePost(post, req.user.id) });
  } catch (err) {
    next(err);
  }
}

// GET /api/posts/feed?page=&limit=
// Returns posts from users the current user follows, plus their own posts.
async function getFeed(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(50, parseInt(req.query.limit) || 10);

    const following = await prisma.follow.findMany({
      where: { followerId: req.user.id },
      select: { followingId: true },
    });
    const authorIds = [req.user.id, ...following.map((f) => f.followingId)];

    const posts = await prisma.post.findMany({
      where: { authorId: { in: authorIds } },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
      include: {
        author: { select: AUTHOR_SELECT },
        likes: { where: { userId: req.user.id }, select: { userId: true } },
        _count: { select: { likes: true, comments: true } },
      },
    });

    res.json({ posts: posts.map((p) => shapePost(p, req.user.id)), page, limit });
  } catch (err) {
    next(err);
  }
}

// GET /api/posts/explore - public posts, newest first (discovery feed)
async function explorePosts(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(50, parseInt(req.query.limit) || 12);

    const posts = await prisma.post.findMany({
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
      include: {
        author: { select: AUTHOR_SELECT },
        likes: req.user ? { where: { userId: req.user.id }, select: { userId: true } } : false,
        _count: { select: { likes: true, comments: true } },
      },
    });

    res.json({ posts: posts.map((p) => shapePost(p, req.user?.id)), page, limit });
  } catch (err) {
    next(err);
  }
}

// GET /api/posts/user/:username
async function getUserPosts(req, res, next) {
  try {
    const user = await prisma.user.findUnique({ where: { username: req.params.username } });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const posts = await prisma.post.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      include: {
        author: { select: AUTHOR_SELECT },
        likes: req.user ? { where: { userId: req.user.id }, select: { userId: true } } : false,
        _count: { select: { likes: true, comments: true } },
      },
    });

    res.json({ posts: posts.map((p) => shapePost(p, req.user?.id)) });
  } catch (err) {
    next(err);
  }
}

// GET /api/posts/:id
async function getPost(req, res, next) {
  try {
    const post = await prisma.post.findUnique({
      where: { id: req.params.id },
      include: {
        author: { select: AUTHOR_SELECT },
        likes: req.user ? { where: { userId: req.user.id }, select: { userId: true } } : false,
        _count: { select: { likes: true, comments: true } },
      },
    });
    if (!post) return res.status(404).json({ message: 'Post not found' });

    res.json({ post: shapePost(post, req.user?.id) });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/posts/:id
async function deletePost(req, res, next) {
  try {
    const post = await prisma.post.findUnique({ where: { id: req.params.id } });
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (post.authorId !== req.user.id) {
      return res.status(403).json({ message: 'You can only delete your own posts' });
    }

    await prisma.post.delete({ where: { id: post.id } });
    res.json({ message: 'Post deleted' });
  } catch (err) {
    next(err);
  }
}

// POST /api/posts/:id/like
async function likePost(req, res, next) {
  try {
    const post = await prisma.post.findUnique({ where: { id: req.params.id } });
    if (!post) return res.status(404).json({ message: 'Post not found' });

    await prisma.like.create({ data: { userId: req.user.id, postId: post.id } });

    if (post.authorId !== req.user.id) {
      await prisma.notification.create({
        data: { type: 'LIKE', recipientId: post.authorId, actorId: req.user.id, postId: post.id },
      });
    }

    res.status(201).json({ message: 'Post liked' });
  } catch (err) {
    if (err.code === 'P2002') {
      return res.status(409).json({ message: 'Post already liked' });
    }
    next(err);
  }
}

// DELETE /api/posts/:id/like
async function unlikePost(req, res, next) {
  try {
    await prisma.like.delete({
      where: { userId_postId: { userId: req.user.id, postId: req.params.id } },
    });
    res.json({ message: 'Post unliked' });
  } catch (err) {
    if (err.code === 'P2025') {
      return res.status(404).json({ message: 'You have not liked this post' });
    }
    next(err);
  }
}

// GET /api/posts/:id/comments
async function getComments(req, res, next) {
  try {
    const comments = await prisma.comment.findMany({
      where: { postId: req.params.id },
      orderBy: { createdAt: 'asc' },
      include: { user: { select: AUTHOR_SELECT } },
    });
    res.json({ comments });
  } catch (err) {
    next(err);
  }
}

// POST /api/posts/:id/comments
async function addComment(req, res, next) {
  try {
    const { text } = req.body;
    const post = await prisma.post.findUnique({ where: { id: req.params.id } });
    if (!post) return res.status(404).json({ message: 'Post not found' });

    const comment = await prisma.comment.create({
      data: { text, userId: req.user.id, postId: post.id },
      include: { user: { select: AUTHOR_SELECT } },
    });

    if (post.authorId !== req.user.id) {
      await prisma.notification.create({
        data: { type: 'COMMENT', recipientId: post.authorId, actorId: req.user.id, postId: post.id },
      });
    }

    res.status(201).json({ comment });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/posts/:postId/comments/:commentId
async function deleteComment(req, res, next) {
  try {
    const comment = await prisma.comment.findUnique({ where: { id: req.params.commentId } });
    if (!comment) return res.status(404).json({ message: 'Comment not found' });

    const post = await prisma.post.findUnique({ where: { id: comment.postId } });
    const isOwner = comment.userId === req.user.id || post.authorId === req.user.id;
    if (!isOwner) return res.status(403).json({ message: 'Not authorized to delete this comment' });

    await prisma.comment.delete({ where: { id: comment.id } });
    res.json({ message: 'Comment deleted' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createPost,
  getFeed,
  explorePosts,
  getUserPosts,
  getPost,
  deletePost,
  likePost,
  unlikePost,
  getComments,
  addComment,
  deleteComment,
};
