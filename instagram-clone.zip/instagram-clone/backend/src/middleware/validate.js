const { validationResult } = require('express-validator');

// Runs after express-validator chains; returns 400 with details if any failed.
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
  }
  next();
}

module.exports = validate;
