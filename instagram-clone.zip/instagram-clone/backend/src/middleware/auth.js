const jwt = require('jsonwebtoken');

/**
 * Verifies the Bearer token sent in the Authorization header and
 * attaches the decoded payload ({ id, username }) to req.user.
 */
function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Authentication token missing' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

/**
 * Optional auth: attaches req.user if a valid token is present,
 * but does not reject the request if absent. Useful for endpoints
 * whose response varies for logged-in users (e.g. "isFollowing").
 */
function optionalAuthenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) return next();

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    // ignore invalid token for optional auth
  }
  next();
}

module.exports = { authenticate, optionalAuthenticate };
