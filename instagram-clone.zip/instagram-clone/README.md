# InstaClone — Instagram-style Social Media App

A full-stack social media application with user accounts, photo/video posts, feeds, likes,
comments, follow/unfollow, direct messaging, search, and notifications.

**Stack**

| Layer      | Technology |
|------------|------------|
| Frontend   | React 18 + Vite, React Router, Tailwind CSS, Axios, Socket.IO client |
| Backend    | Node.js + Express, Prisma ORM, JWT auth, Multer (uploads), Socket.IO |
| Database   | PostgreSQL |
| Deployment | Docker + Docker Compose, Nginx (frontend), serves static uploads |

---

## 1. Project Structure

```
instagram-clone/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma     # Database schema (models, relations)
│   │   └── seed.js           # Demo data seeder
│   ├── src/
│   │   ├── config/prisma.js  # Prisma client singleton
│   │   ├── controllers/       # Business logic per resource
│   │   ├── middleware/        # auth, upload, validation, error handling
│   │   ├── routes/             # Express route definitions
│   │   ├── app.js              # Express app (middleware, routes)
│   │   └── server.js           # HTTP + Socket.IO server entrypoint
│   ├── uploads/                # Uploaded media (gitignored)
│   ├── .env.example
│   ├── Dockerfile
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── api/client.js       # Axios instance with auth interceptor
│   │   ├── context/AuthContext.jsx
│   │   ├── hooks/useSocket.js
│   │   ├── components/         # Layout, PostCard
│   │   ├── pages/               # Login, Register, Feed, Explore, Profile, etc.
│   │   ├── App.jsx               # Route definitions
│   │   └── main.jsx
│   ├── Dockerfile
│   ├── nginx.conf
│   └── package.json
├── docker-compose.yml
└── README.md
```

---

## 2. Architecture Overview

### Database (PostgreSQL via Prisma)

Core models in `backend/prisma/schema.prisma`:

- **User** — account info, profile (bio, avatar, privacy flag)
- **Post** — media (image/video), caption, author
- **Like** — unique per (user, post)
- **Comment** — text on a post
- **Follow** — directed edge (follower → following), unique per pair
- **Message** — direct message between two users
- **Notification** — generated on like, comment, follow, and message events

Relationships are enforced with foreign keys and cascading deletes, and indexed on
frequently-queried columns (`authorId`, `postId`, `followingId`, `recipientId`).

### Backend (Express + Prisma)

- **Authentication**: JWT-based. `POST /api/auth/register` and `/login` issue a signed
  token; `authenticate` middleware verifies it on protected routes and attaches `req.user`.
- **Security**: `helmet` for HTTP headers, `cors` restricted to the configured client
  origin, `express-rate-limit` (global + stricter on auth endpoints), `bcryptjs` for
  password hashing, `express-validator` for input validation.
- **File uploads**: `multer` stores images/videos on disk under `/uploads`, validated by
  MIME type and size limit (`MAX_FILE_SIZE_MB`). Files are served statically at `/uploads/*`.
- **Real-time**: `socket.io` authenticates connections via the same JWT. Each user joins a
  private room (`user:<id>`); the message controller emits `new_message` events to the
  recipient's room for instant delivery.
- **Error handling**: a centralized `errorHandler` middleware maps Prisma error codes
  (e.g. unique constraint `P2002`, not-found `P2025`) and Multer errors to clean HTTP
  responses.

### Frontend (React + Vite)

- **Routing**: `react-router-dom` with `PrivateRoute`/`PublicOnlyRoute` guards based on
  `AuthContext`.
- **State**: `AuthContext` persists the JWT and user object in `localStorage` and
  validates the session via `/api/auth/me` on load.
- **API layer**: a single Axios instance (`src/api/client.js`) injects the `Authorization`
  header and clears the session on `401` responses.
- **Real-time**: `useSocket` hook opens an authenticated Socket.IO connection, used by the
  Messages page to receive `new_message` events live.
- **UI**: Tailwind CSS for a responsive, mobile-first layout — bottom tab bar on mobile,
  left sidebar on desktop (`Layout.jsx`).

---

## 3. Local Development Setup

### Prerequisites
- Node.js 18+
- PostgreSQL 14+ (running locally), or use Docker (see section 5)

### Backend

```bash
cd backend
cp .env.example .env
# edit .env: set DATABASE_URL to your local Postgres connection string,
# and JWT_SECRET to a long random string

npm install
npx prisma migrate dev --name init   # creates tables
npm run seed                          # optional: demo users alice/bob, password "password123"
npm run dev                           # starts on http://localhost:5000
```

### Frontend

```bash
cd frontend
npm install
npm run dev    # starts on http://localhost:5173, proxies /api and /uploads to :5000
```

Open `http://localhost:5173`, register a new account (or log in as `alice` /
`password123` after seeding), and start posting.

---

## 4. API Documentation

Base URL: `/api`. Protected routes require `Authorization: Bearer <token>`.

### Auth

| Method | Endpoint            | Auth | Description |
|--------|---------------------|------|-------------|
| POST   | `/auth/register`    | No   | Body: `{ username, email, password, fullName? }`. Returns `{ user, token }`. |
| POST   | `/auth/login`       | No   | Body: `{ emailOrUsername, password }`. Returns `{ user, token }`. |
| GET    | `/auth/me`          | Yes  | Returns the current user's profile. |

### Users

| Method | Endpoint                       | Auth | Description |
|--------|--------------------------------|------|-------------|
| GET    | `/users/search?q=term`         | No   | Search users by username/full name. |
| GET    | `/users/:username`             | Optional | Profile + post/follower/following counts + `isFollowing` (if authenticated). |
| PUT    | `/users/me`                    | Yes  | Multipart form: `fullName`, `bio`, `isPrivate`, `avatar` (file). |
| PUT    | `/users/me/password`           | Yes  | Body: `{ currentPassword, newPassword }`. |
| GET    | `/users/:username/followers`   | No   | List of followers. |
| GET    | `/users/:username/following`   | No   | List of accounts followed. |
| POST   | `/users/:username/follow`      | Yes  | Follow a user (creates a `FOLLOW` notification). |
| DELETE | `/users/:username/follow`      | Yes  | Unfollow a user. |

### Posts

| Method | Endpoint                              | Auth | Description |
|--------|----------------------------------------|------|-------------|
| GET    | `/posts/feed?page=&limit=`             | Yes  | Posts from followed users + self, paginated, newest first. |
| GET    | `/posts/explore?page=&limit=`          | Optional | All posts, newest first (discovery grid). |
| GET    | `/posts/user/:username`                | Optional | All posts by a user. |
| POST   | `/posts`                                | Yes  | Multipart form: `media` (file, required), `caption`. Creates an image or video post. |
| GET    | `/posts/:id`                           | Optional | Single post detail. |
| DELETE | `/posts/:id`                           | Yes  | Delete own post. |
| POST   | `/posts/:id/like`                      | Yes  | Like a post (creates a `LIKE` notification). |
| DELETE | `/posts/:id/like`                      | Yes  | Unlike a post. |
| GET    | `/posts/:id/comments`                  | No   | List comments, oldest first. |
| POST   | `/posts/:id/comments`                  | Yes  | Body: `{ text }`. Creates a `COMMENT` notification. |
| DELETE | `/posts/:postId/comments/:commentId`   | Yes  | Delete a comment (author or post owner). |

### Messages

| Method | Endpoint                  | Auth | Description |
|--------|---------------------------|------|-------------|
| GET    | `/messages/conversations` | Yes  | List of conversations with last message + unread count. |
| GET    | `/messages/:username`     | Yes  | Full thread with a user; marks incoming messages as read. |
| POST   | `/messages/:username`     | Yes  | Body: `{ content }`. Sends a message and emits a real-time `new_message` socket event. |

### Notifications

| Method | Endpoint                     | Auth | Description |
|--------|-------------------------------|------|-------------|
| GET    | `/notifications`              | Yes  | Last 50 notifications (likes, comments, follows, messages). |
| GET    | `/notifications/unread-count` | Yes  | Count of unread notifications (polled by the UI). |
| PUT    | `/notifications/read`         | Yes  | Marks all notifications as read. |

### Real-time (Socket.IO)

- Connect with `auth: { token: <JWT> }`.
- Server places the socket in room `user:<userId>`.
- Event `new_message`: emitted to the recipient when a new direct message is created.

---

## 5. Deployment (Docker Compose)

This spins up PostgreSQL, the backend API, and an Nginx-served frontend build.

```bash
docker compose up --build -d
```

- Frontend: `http://localhost:8080`
- Backend API: `http://localhost:5000/api`
- Postgres: `localhost:5432` (user/pass: `postgres`/`postgres`, db: `instaclone`)

On first run, the backend container automatically runs `prisma migrate deploy`. To seed
demo data:

```bash
docker compose exec backend npm run seed
```

**Before deploying to production:**
1. Change `JWT_SECRET` and the database password in `docker-compose.yml` (or use a `.env`
   file with Compose's `env_file:` option).
2. Set `CLIENT_URL` to your real frontend domain (used for CORS).
3. Put the stack behind HTTPS (e.g. a reverse proxy like Caddy or Traefik, or a managed
   load balancer with TLS termination).
4. For scale, move uploaded media to object storage (S3-compatible) instead of the local
   `uploads` volume, and point `mediaUrl` at that storage's public URL.

---

## 6. Security Notes

- Passwords are hashed with bcrypt (10 rounds) — never stored or returned in plaintext.
- JWTs expire after `JWT_EXPIRES_IN` (default 7 days); the frontend clears the session on
  `401` responses.
- All write endpoints validate input via `express-validator`.
- File uploads are restricted by MIME type and size; filenames are randomized to avoid
  collisions and path traversal.
- Rate limiting is applied globally and more strictly to `/auth/login` and
  `/auth/register` to slow brute-force attempts.
- Authorization checks ensure users can only modify their own posts, comments, and
  profile.

---

## 7. Possible Extensions

- Stories (24h ephemeral media) — add a `Story` model with `expiresAt` and a cron/cleanup job.
- Hashtags and post search — add a `Hashtag` model and many-to-many relation to `Post`.
- Push notifications — integrate a service worker + Web Push API.
- Infinite scroll — replace the "Load more" button with an `IntersectionObserver`.
- Image processing — generate thumbnails/resized variants on upload (e.g. with `sharp`).
