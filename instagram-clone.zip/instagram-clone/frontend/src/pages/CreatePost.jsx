import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/client';

export default function CreatePost() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [caption, setCaption] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  function handleFileChange(e) {
    const selected = e.target.files[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!file) {
      setError('Please select a photo or video');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('media', file);
      formData.append('caption', caption);
      const { data } = await api.post('/posts', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      navigate(`/posts/${data.post.id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create post');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-xl font-semibold mb-4">Create new post</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <label className="border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center h-64 cursor-pointer overflow-hidden bg-gray-50">
          {preview ? (
            file.type.startsWith('video') ? (
              <video src={preview} className="h-full w-full object-contain" controls />
            ) : (
              <img src={preview} alt="preview" className="h-full w-full object-contain" />
            )
          ) : (
            <span className="text-gray-500">Click to select a photo or video</span>
          )}
          <input type="file" accept="image/*,video/*" onChange={handleFileChange} className="hidden" />
        </label>
        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Write a caption..."
          rows={3}
          maxLength={2200}
          className="border border-gray-300 rounded px-3 py-2 text-sm"
        />
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="bg-brand-500 text-white rounded py-2 font-semibold disabled:opacity-50"
        >
          {loading ? 'Posting...' : 'Share'}
        </button>
      </form>
    </div>
  );
}
