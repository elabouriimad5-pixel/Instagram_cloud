import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import { Play } from 'lucide-react';

export default function Explore() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/posts/explore', { params: { limit: 30 } })
      .then(({ data }) => setPosts(data.posts))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="text-center py-10 text-gray-500">Loading...</div>;

  return (
    <div className="grid grid-cols-3 gap-1 p-1">
      {posts.map((post) => (
        <Link key={post.id} to={`/posts/${post.id}`} className="relative aspect-square bg-gray-100">
          {post.mediaType === 'VIDEO' ? (
            <>
              <video src={post.mediaUrl} className="w-full h-full object-cover" />
              <Play size={18} className="absolute top-2 right-2 text-white fill-white" />
            </>
          ) : (
            <img src={post.mediaUrl} alt={post.caption || 'post'} className="w-full h-full object-cover" />
          )}
        </Link>
      ))}
      {posts.length === 0 && (
        <p className="col-span-3 text-center text-gray-500 py-10">No posts yet.</p>
      )}
    </div>
  );
}
