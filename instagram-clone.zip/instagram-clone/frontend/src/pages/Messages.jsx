import { useEffect, useRef, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../hooks/useSocket';
import { ArrowLeft } from 'lucide-react';

export default function Messages() {
  const { username } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const socketRef = useSocket();

  const [conversations, setConversations] = useState([]);
  const [thread, setThread] = useState(null); // { messages, otherUser }
  const [text, setText] = useState('');
  const [loadingConvos, setLoadingConvos] = useState(true);
  const [loadingThread, setLoadingThread] = useState(false);
  const bottomRef = useRef(null);

  // Load conversation list
  useEffect(() => {
    api.get('/messages/conversations')
      .then(({ data }) => setConversations(data.conversations))
      .finally(() => setLoadingConvos(false));
  }, []);

  // Load active thread when username param changes
  useEffect(() => {
    if (!username) {
      setThread(null);
      return;
    }
    setLoadingThread(true);
    api.get(`/messages/${username}`)
      .then(({ data }) => setThread(data))
      .finally(() => setLoadingThread(false));
  }, [username]);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [thread]);

  // Listen for real-time incoming messages
  useEffect(() => {
    const socket = socketRef.current;
    if (!socket) return;

    function handleNewMessage(msg) {
      // If the message belongs to the open thread, append it
      setThread((prev) => {
        if (!prev) return prev;
        const isForThisThread =
          (msg.senderId === prev.otherUser.id) || (msg.receiverId === prev.otherUser.id);
        if (!isForThisThread) return prev;
        return { ...prev, messages: [...prev.messages, msg] };
      });

      // Refresh conversation list summaries
      api.get('/messages/conversations').then(({ data }) => setConversations(data.conversations));
    }

    socket.on('new_message', handleNewMessage);
    return () => socket.off('new_message', handleNewMessage);
  }, [socketRef]);

  async function handleSend(e) {
    e.preventDefault();
    if (!text.trim() || !username) return;
    const { data } = await api.post(`/messages/${username}`, { content: text });
    setThread((prev) => ({ ...prev, messages: [...prev.messages, data.message] }));
    setText('');
  }

  // --- Conversation list view (no username selected, or desktop split view) ---
  const ConversationList = (
    <div className={`${username ? 'hidden md:block' : ''} md:w-80 border-r border-gray-200 h-[calc(100vh-3.5rem)] md:h-screen overflow-y-auto`}>
      <h1 className="text-lg font-semibold px-4 py-3 border-b border-gray-200">Messages</h1>
      {loadingConvos ? (
        <p className="text-center text-gray-500 py-6">Loading...</p>
      ) : conversations.length === 0 ? (
        <p className="text-center text-gray-500 py-6 px-4">No conversations yet. Visit a profile and tap Message.</p>
      ) : (
        <ul>
          {conversations.map((c) => (
            <li key={c.user.id}>
              <Link
                to={`/messages/${c.user.username}`}
                className={`flex items-center gap-3 px-4 py-3 hover:bg-gray-50 ${username === c.user.username ? 'bg-gray-50' : ''}`}
              >
                <img
                  src={c.user.avatarUrl || '/default-avatar.svg'}
                  alt={c.user.username}
                  className="w-12 h-12 rounded-full object-cover bg-gray-200"
                  onError={(e) => { e.target.style.visibility = 'hidden'; }}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{c.user.username}</p>
                  <p className="text-gray-500 text-sm truncate">{c.lastMessage.content}</p>
                </div>
                {c.unreadCount > 0 && (
                  <span className="bg-brand-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {c.unreadCount}
                  </span>
                )}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );

  // --- Thread view ---
  const ThreadView = username && (
    <div className="flex-1 flex flex-col h-[calc(100vh-3.5rem)] md:h-screen">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-200">
        <button onClick={() => navigate('/messages')} className="md:hidden">
          <ArrowLeft size={20} />
        </button>
        {thread?.otherUser && (
          <Link to={`/${thread.otherUser.username}`} className="flex items-center gap-2">
            <img
              src={thread.otherUser.avatarUrl || '/default-avatar.svg'}
              alt={thread.otherUser.username}
              className="w-8 h-8 rounded-full object-cover bg-gray-200"
              onError={(e) => { e.target.style.visibility = 'hidden'; }}
            />
            <span className="font-semibold text-sm">{thread.otherUser.username}</span>
          </Link>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2">
        {loadingThread ? (
          <p className="text-center text-gray-500">Loading...</p>
        ) : (
          thread?.messages.map((m) => (
            <div
              key={m.id}
              className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${
                m.senderId === user.id ? 'bg-brand-500 text-white self-end' : 'bg-gray-100 self-start'
              }`}
            >
              {m.content}
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={handleSend} className="flex gap-2 px-4 py-3 border-t border-gray-200">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Message..."
          className="flex-1 border border-gray-300 rounded-full px-4 py-2 text-sm"
        />
        <button type="submit" className="text-brand-500 font-semibold text-sm">Send</button>
      </form>
    </div>
  );

  return (
    <div className="flex">
      {ConversationList}
      {ThreadView}
      {!username && (
        <div className="hidden md:flex flex-1 items-center justify-center text-gray-400">
          Select a conversation
        </div>
      )}
    </div>
  );
}
