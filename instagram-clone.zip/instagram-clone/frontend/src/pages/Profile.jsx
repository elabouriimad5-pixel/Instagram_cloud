import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';
import { Play } from 'lucide-react';

export default function Profile() {
  const { username } = useParams();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [followBusy, setFollowBusy] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [{ data: profileData }, { data: postsData }] = await Promise.all([
        api.get(`/users/${username}`),
        api.get(`/posts/user/${username}`),
      ]);
      setProfile(profileData);
      setPosts(postsData.posts);
    } catch {
      navigate('/');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [username]);

  async function toggleFollow() {
    if (followBusy) return;
    setFollowBusy(true);
    try {
      if (profile.isFollowing) {
        await api.delete(`/users/${username}/follow`);
        setProfile((p) => ({ ...p, isFollowing: false, _count: { ...p._count, followers: p._count.followers - 1 } }));
      } else {
        await api.post(`/users/${username}/follow`);
        setProfile((p) => ({ ...p, isFollowing: true, _count: { ...p._count, followers: p._count.followers + 1 } }));
      }
    } finally {
      setFollowBusy(false);
    }
  }

  if (loading) return <div className="text-center py-10 text-gray-500">Loading...</div>;
  if (!profile) return null;

  const isOwnProfile = currentUser?.username === username;

  return (
    <div className="p-4">
      <div className="flex items-center gap-6 sm:gap-12 mb-6">
        <img
          src={profile.avatarUrl || '/default-avatar.svg'}
          alt={profile.username}
          className="w-20 h-20 sm:w-32 sm:h-32 rounded-full object-cover bg-gray-200"
          onError={(e) => { e.target.style.visibility = 'hidden'; }}
        />
        <div className="flex-1">
          <div className="flex items-center gap-4 mb-2 flex-wrap">
            <h1 className="text-lg font-semibold">{profile.username}</h1>
            {isOwnProfile ? (
              <Link to="/profile/edit" className="bg-gray-100 px-4 py-1.5 rounded-lg text-sm font-semibold">
                Edit Profile
              </Link>
            ) : (
              <>
                <button
                  onClick={toggleFollow}
                  disabled={followBusy}
                  className={`px-4 py-1.5 rounded-lg text-sm font-semibold ${
                    profile.isFollowing ? 'bg-gray-100' : 'bg-brand-500 text-white'
                  }`}
                >
                  {profile.isFollowing ? 'Following' : 'Follow'}
                </button>
                <Link to={`/messages/${profile.username}`} className="bg-gray-100 px-4 py-1.5 rounded-lg text-sm font-semibold">
                  Message
                </Link>
              </>
            )}
          </div>
          <div className="flex gap-6 text-sm mb-2">
            <span><strong>{profile._count.posts}</strong> posts</span>
            <span><strong>{profile._count.followers}</strong> followers</span>
            <span><strong>{profile._count.following}</strong> following</span>
          </div>
          {profile.fullName && <p className="font-semibold text-sm">{profile.fullName}</p>}
          {profile.bio && <p className="text-sm whitespace-pre-line">{profile.bio}</p>}
        </div>
      </div>

      <div className="border-t border-gray-200 grid grid-cols-3 gap-1 pt-4">
        {posts.map((post) => (
          <Link key={post.id} to={`/posts/${post.id}`} className="relative aspect-square bg-gray-100">
            {post.mediaType === 'VIDEO' ? (
              <>
                <video src={post.mediaUrl} className="w-full h-full object-cover" />
                <Play size={18} className="absolute top-2 right-2 text-white fill-white" />
              </>
            ) : (
              <img src={post.mediaUrl} alt={post.caption || 'post'} className="w-full h-full object-cover" />
            )}
          </Link>
        ))}
        {posts.length === 0 && (
          <p className="col-span-3 text-center text-gray-500 py-10">No posts yet.</p>
        )}
      </div>
    </div>
  );
}
