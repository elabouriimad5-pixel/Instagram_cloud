import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const [form, setForm] = useState({ username: '', email: '', password: '', fullName: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/register', form);
      login(data.user, data.token);
      navigate('/');
    } catch (err) {
      const msg = err.response?.data?.errors?.[0]?.msg || err.response?.data?.message || 'Registration failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-sm">
        <div className="border border-gray-200 bg-white rounded-lg p-8 text-center">
          <h1 className="text-3xl font-serif font-bold mb-2">InstaClone</h1>
          <p className="text-gray-500 text-sm mb-6">Sign up to see photos and videos from your friends.</p>
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <input
              name="fullName"
              placeholder="Full Name"
              value={form.fullName}
              onChange={handleChange}
              className="border border-gray-300 rounded px-3 py-2 text-sm"
            />
            <input
              name="username"
              placeholder="Username"
              value={form.username}
              onChange={handleChange}
              className="border border-gray-300 rounded px-3 py-2 text-sm"
              required
            />
            <input
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              className="border border-gray-300 rounded px-3 py-2 text-sm"
              required
            />
            <input
              name="password"
              type="password"
              placeholder="Password"
              value={form.password}
              onChange={handleChange}
              className="border border-gray-300 rounded px-3 py-2 text-sm"
              required
            />
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="bg-brand-500 text-white rounded py-2 font-semibold disabled:opacity-50"
            >
              {loading ? 'Signing up...' : 'Sign up'}
            </button>
          </form>
        </div>
        <div className="border border-gray-200 bg-white rounded-lg p-4 mt-4 text-center text-sm">
          Have an account?{' '}
          <Link to="/login" className="text-brand-500 font-semibold">
            Log in
          </Link>
        </div>
      </div>
    </div>
  );
}
