import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';

const MESSAGES = {
  LIKE: 'liked your post',
  COMMENT: 'commented on your post',
  FOLLOW: 'started following you',
  MESSAGE: 'sent you a message',
};

export default function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/notifications')
      .then(({ data }) => setNotifications(data.notifications))
      .finally(() => setLoading(false));

    // Mark as read once viewed
    api.put('/notifications/read');
  }, []);

  if (loading) return <div className="text-center py-10 text-gray-500">Loading...</div>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-semibold mb-4">Notifications</h1>
      {notifications.length === 0 ? (
        <p className="text-gray-500">No notifications yet.</p>
      ) : (
        <ul className="flex flex-col gap-1">
          {notifications.map((n) => (
            <li key={n.id} className={`flex items-center gap-3 py-2 px-1 rounded ${!n.read ? 'bg-blue-50' : ''}`}>
              <Link to={`/${n.actor.username}`}>
                <img
                  src={n.actor.avatarUrl || '/default-avatar.svg'}
                  alt={n.actor.username}
                  className="w-10 h-10 rounded-full object-cover bg-gray-200"
                  onError={(e) => { e.target.style.visibility = 'hidden'; }}
                />
              </Link>
              <p className="text-sm flex-1">
                <Link to={`/${n.actor.username}`} className="font-semibold mr-1">{n.actor.username}</Link>
                {MESSAGES[n.type] || 'sent a notification'}
                <span className="text-gray-400 ml-2 text-xs">{new Date(n.createdAt).toLocaleDateString()}</span>
              </p>
              {n.post && (
                <Link to={`/posts/${n.post.id}`}>
                  <img src={n.post.mediaUrl} alt="post" className="w-10 h-10 object-cover rounded" />
                </Link>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
