import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function EditProfile() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [isPrivate, setIsPrivate] = useState(user?.isPrivate || false);
  const [avatar, setAvatar] = useState(null);
  const [preview, setPreview] = useState(user?.avatarUrl || null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Password change fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [pwMessage, setPwMessage] = useState('');

  function handleAvatarChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    setAvatar(file);
    setPreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('fullName', fullName);
      formData.append('bio', bio);
      formData.append('isPrivate', isPrivate);
      if (avatar) formData.append('avatar', avatar);

      const { data } = await api.put('/users/me', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      updateUser({ ...user, ...data.user });
      navigate(`/${user.username}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  }

  async function handlePasswordChange(e) {
    e.preventDefault();
    setPwMessage('');
    try {
      const { data } = await api.put('/users/me/password', { currentPassword, newPassword });
      setPwMessage(data.message);
      setCurrentPassword('');
      setNewPassword('');
    } catch (err) {
      setPwMessage(err.response?.data?.message || 'Failed to change password');
    }
  }

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-xl font-semibold mb-4">Edit Profile</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3 mb-8">
        <label className="flex items-center gap-4 cursor-pointer">
          <img
            src={preview || '/default-avatar.svg'}
            alt="avatar"
            className="w-16 h-16 rounded-full object-cover bg-gray-200"
            onError={(e) => { e.target.style.visibility = 'hidden'; }}
          />
          <span className="text-brand-500 font-semibold text-sm">Change profile photo</span>
          <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
        </label>

        <label className="text-sm font-semibold">Full Name</label>
        <input
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="border border-gray-300 rounded px-3 py-2 text-sm"
        />

        <label className="text-sm font-semibold">Bio</label>
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          maxLength={250}
          rows={3}
          className="border border-gray-300 rounded px-3 py-2 text-sm"
        />

        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={isPrivate} onChange={(e) => setIsPrivate(e.target.checked)} />
          Private account
        </label>

        {error && <p className="text-red-500 text-sm">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="bg-brand-500 text-white rounded py-2 font-semibold disabled:opacity-50"
        >
          {loading ? 'Saving...' : 'Save Changes'}
        </button>
      </form>

      <h2 className="text-lg font-semibold mb-2">Change Password</h2>
      <form onSubmit={handlePasswordChange} className="flex flex-col gap-3">
        <input
          type="password"
          placeholder="Current password"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          className="border border-gray-300 rounded px-3 py-2 text-sm"
          required
        />
        <input
          type="password"
          placeholder="New password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="border border-gray-300 rounded px-3 py-2 text-sm"
          required
        />
        {pwMessage && <p className="text-sm">{pwMessage}</p>}
        <button type="submit" className="bg-gray-100 rounded py-2 font-semibold">
          Update Password
        </button>
      </form>
    </div>
  );
}
