import { useEffect, useState, useCallback } from 'react';
import api from '../api/client';
import PostCard from '../components/PostCard';

export default function Feed() {
  const [posts, setPosts] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);

  const loadPage = useCallback(async (pageNum) => {
    setLoading(true);
    try {
      const { data } = await api.get('/posts/feed', { params: { page: pageNum, limit: 10 } });
      setPosts((prev) => (pageNum === 1 ? data.posts : [...prev, ...data.posts]));
      setHasMore(data.posts.length === 10);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPage(1);
  }, [loadPage]);

  function handleDelete(id) {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  }

  function loadMore() {
    const next = page + 1;
    setPage(next);
    loadPage(next);
  }

  if (loading && posts.length === 0) {
    return <div className="text-center py-10 text-gray-500">Loading feed...</div>;
  }

  if (posts.length === 0) {
    return (
      <div className="text-center py-16 px-4">
        <h2 className="text-xl font-semibold mb-2">Your feed is empty</h2>
        <p className="text-gray-500">Follow people to see their posts here, or check out Explore.</p>
      </div>
    );
  }

  return (
    <div className="px-0 sm:px-4 py-4">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} onDelete={handleDelete} />
      ))}
      {hasMore && (
        <button
          onClick={loadMore}
          disabled={loading}
          className="w-full text-center text-brand-500 font-semibold py-3 disabled:opacity-50"
        >
          {loading ? 'Loading...' : 'Load more'}
        </button>
      )}
    </div>
  );
}
