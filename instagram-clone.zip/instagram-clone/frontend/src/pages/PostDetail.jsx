import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../api/client';
import PostCard from '../components/PostCard';
import { useAuth } from '../context/AuthContext';
import { Trash2 } from 'lucide-react';

export default function PostDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [{ data: postData }, { data: commentData }] = await Promise.all([
        api.get(`/posts/${id}`),
        api.get(`/posts/${id}/comments`),
      ]);
      setPost(postData.post);
      setComments(commentData.comments);
    } catch {
      navigate('/');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleAddComment(e) {
    e.preventDefault();
    if (!text.trim()) return;
    const { data } = await api.post(`/posts/${id}/comments`, { text });
    setComments((prev) => [...prev, data.comment]);
    setText('');
    setPost((p) => ({ ...p, commentCount: p.commentCount + 1 }));
  }

  async function handleDeleteComment(commentId) {
    await api.delete(`/posts/${id}/comments/${commentId}`);
    setComments((prev) => prev.filter((c) => c.id !== commentId));
    setPost((p) => ({ ...p, commentCount: p.commentCount - 1 }));
  }

  function handlePostDelete() {
    navigate('/');
  }

  if (loading) return <div className="text-center py-10 text-gray-500">Loading...</div>;
  if (!post) return null;

  return (
    <div className="p-0 sm:p-4">
      <PostCard post={post} onDelete={handlePostDelete} />

      <div className="border border-gray-200 bg-white rounded-lg p-4 -mt-4">
        <h3 className="font-semibold text-sm mb-3">Comments</h3>
        <ul className="flex flex-col gap-2 mb-3">
          {comments.map((c) => (
            <li key={c.id} className="flex items-start justify-between gap-2 text-sm">
              <p>
                <Link to={`/${c.user.username}`} className="font-semibold mr-1">{c.user.username}</Link>
                {c.text}
              </p>
              {(c.user.id === user?.id || post.author.id === user?.id) && (
                <button onClick={() => handleDeleteComment(c.id)} className="text-gray-400 shrink-0">
                  <Trash2 size={14} />
                </button>
              )}
            </li>
          ))}
          {comments.length === 0 && <p className="text-gray-500 text-sm">No comments yet.</p>}
        </ul>
        <form onSubmit={handleAddComment} className="flex gap-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Add a comment..."
            maxLength={500}
            className="flex-1 border border-gray-300 rounded px-3 py-2 text-sm"
          />
          <button type="submit" className="text-brand-500 font-semibold text-sm px-2">
            Post
          </button>
        </form>
      </div>
    </div>
  );
}
