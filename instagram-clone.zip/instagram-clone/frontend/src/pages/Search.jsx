import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';

export default function Search() {
  const [query, setQuery] = useState('');
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  let debounceTimer;

  function handleChange(e) {
    const value = e.target.value;
    setQuery(value);

    clearTimeout(debounceTimer);
    if (!value.trim()) {
      setUsers([]);
      return;
    }
    debounceTimer = setTimeout(async () => {
      setLoading(true);
      try {
        const { data } = await api.get('/users/search', { params: { q: value } });
        setUsers(data.users);
      } finally {
        setLoading(false);
      }
    }, 300);
  }

  return (
    <div className="p-4">
      <input
        type="text"
        value={query}
        onChange={handleChange}
        placeholder="Search users"
        className="w-full border border-gray-300 rounded-lg px-4 py-2 mb-4 bg-gray-100"
        autoFocus
      />
      {loading && <p className="text-gray-500 text-sm">Searching...</p>}
      <ul>
        {users.map((u) => (
          <li key={u.id}>
            <Link to={`/${u.username}`} className="flex items-center gap-3 py-2">
              <img
                src={u.avatarUrl || '/default-avatar.svg'}
                alt={u.username}
                className="w-11 h-11 rounded-full object-cover bg-gray-200"
                onError={(e) => { e.target.style.visibility = 'hidden'; }}
              />
              <div>
                <p className="font-semibold text-sm">{u.username}</p>
                {u.fullName && <p className="text-gray-500 text-sm">{u.fullName}</p>}
              </div>
            </Link>
          </li>
        ))}
      </ul>
      {!loading && query && users.length === 0 && (
        <p className="text-gray-500 text-sm">No users found.</p>
      )}
    </div>
  );
}
