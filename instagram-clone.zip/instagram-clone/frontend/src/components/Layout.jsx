import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';
import {
  Home, Search, PlusSquare, Heart, MessageCircle, LogOut, Compass,
} from 'lucide-react';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    let mounted = true;
    async function poll() {
      try {
        const { data } = await api.get('/notifications/unread-count');
        if (mounted) setUnread(data.count);
      } catch {
        /* ignore */
      }
    }
    poll();
    const interval = setInterval(poll, 15000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [location.pathname]);

  function handleLogout() {
    logout();
    navigate('/login');
  }

  const navItems = [
    { to: '/', icon: Home, label: 'Home' },
    { to: '/search', icon: Search, label: 'Search' },
    { to: '/explore', icon: Compass, label: 'Explore' },
    { to: '/create', icon: PlusSquare, label: 'Create' },
    { to: '/messages', icon: MessageCircle, label: 'Messages' },
    { to: '/notifications', icon: Heart, label: 'Notifications', badge: unread },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:flex-col md:w-64 border-r border-gray-200 px-4 py-6 fixed h-full">
        <Link to="/" className="text-2xl font-serif font-bold mb-8 px-2">InstaClone</Link>
        <nav className="flex flex-col gap-1">
          {navItems.map(({ to, icon: Icon, label, badge }) => (
            <Link
              key={to}
              to={to}
              className="flex items-center gap-3 px-2 py-3 rounded-lg hover:bg-gray-100 relative"
            >
              <Icon size={24} />
              <span>{label}</span>
              {!!badge && (
                <span className="absolute left-6 top-1 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </Link>
          ))}
          <Link to={`/${user?.username}`} className="flex items-center gap-3 px-2 py-3 rounded-lg hover:bg-gray-100">
            <img
              src={user?.avatarUrl || '/default-avatar.svg'}
              alt="avatar"
              className="w-6 h-6 rounded-full object-cover bg-gray-200"
              onError={(e) => { e.target.style.visibility = 'hidden'; }}
            />
            <span>Profile</span>
          </Link>
        </nav>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-2 py-3 rounded-lg hover:bg-gray-100 mt-auto text-left"
        >
          <LogOut size={24} />
          <span>Log out</span>
        </button>
      </aside>

      {/* Top bar (mobile) */}
      <header className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gray-200 sticky top-0 bg-white z-10">
        <Link to="/" className="text-xl font-serif font-bold">InstaClone</Link>
        <button onClick={handleLogout} aria-label="Log out">
          <LogOut size={22} />
        </button>
      </header>

      {/* Main content */}
      <main className="flex-1 md:ml-64 pb-16 md:pb-0 max-w-2xl w-full mx-auto md:mx-0 md:max-w-none">
        <div className="md:max-w-2xl md:mx-auto">
          <Outlet />
        </div>
      </main>

      {/* Bottom nav (mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t border-gray-200 bg-white flex justify-around py-2 z-10">
        {navItems.map(({ to, icon: Icon, badge }) => (
          <Link key={to} to={to} className="p-2 relative">
            <Icon size={24} />
            {!!badge && (
              <span className="absolute right-0 top-0 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                {badge > 9 ? '9+' : badge}
              </span>
            )}
          </Link>
        ))}
        <Link to={`/${user?.username}`} className="p-2">
          <img
            src={user?.avatarUrl || '/default-avatar.svg'}
            alt="avatar"
            className="w-6 h-6 rounded-full object-cover bg-gray-200"
            onError={(e) => { e.target.style.visibility = 'hidden'; }}
          />
        </Link>
      </nav>
    </div>
  );
}
