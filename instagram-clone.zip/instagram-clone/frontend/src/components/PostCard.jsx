import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, MessageCircle, Trash2 } from 'lucide-react';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

// Renders a single post: media, author, like/comment actions, caption.
// `onDelete` is called after a successful delete so parent lists can remove it.
export default function PostCard({ post, onDelete }) {
  const { user } = useAuth();
  const [liked, setLiked] = useState(post.likedByMe);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [busy, setBusy] = useState(false);

  async function toggleLike() {
    if (busy) return;
    setBusy(true);
    try {
      if (liked) {
        await api.delete(`/posts/${post.id}/like`);
        setLikeCount((c) => c - 1);
      } else {
        await api.post(`/posts/${post.id}/like`);
        setLikeCount((c) => c + 1);
      }
      setLiked(!liked);
    } catch {
      /* ignore */
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    if (!window.confirm('Delete this post?')) return;
    await api.delete(`/posts/${post.id}`);
    onDelete?.(post.id);
  }

  return (
    <article className="border border-gray-200 bg-white rounded-lg mb-6 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-2">
        <Link to={`/${post.author.username}`} className="flex items-center gap-2">
          <img
            src={post.author.avatarUrl || '/default-avatar.svg'}
            alt={post.author.username}
            className="w-8 h-8 rounded-full object-cover bg-gray-200"
            onError={(e) => { e.target.style.visibility = 'hidden'; }}
          />
          <span className="font-semibold text-sm">{post.author.username}</span>
        </Link>
        {post.author.id === user?.id && (
          <button onClick={handleDelete} aria-label="Delete post" className="text-gray-500">
            <Trash2 size={18} />
          </button>
        )}
      </div>

      <Link to={`/posts/${post.id}`}>
        {post.mediaType === 'VIDEO' ? (
          <video src={post.mediaUrl} className="w-full max-h-[600px] object-cover bg-black" controls />
        ) : (
          <img src={post.mediaUrl} alt={post.caption || 'post'} className="w-full max-h-[600px] object-cover" />
        )}
      </Link>

      <div className="px-3 py-2">
        <div className="flex items-center gap-4">
          <button onClick={toggleLike} aria-label="Like post">
            <Heart size={24} className={liked ? 'fill-red-500 text-red-500' : ''} />
          </button>
          <Link to={`/posts/${post.id}`} aria-label="Comment on post">
            <MessageCircle size={24} />
          </Link>
        </div>
        <p className="font-semibold text-sm mt-2">{likeCount} {likeCount === 1 ? 'like' : 'likes'}</p>
        {post.caption && (
          <p className="text-sm mt-1">
            <Link to={`/${post.author.username}`} className="font-semibold mr-1">{post.author.username}</Link>
            {post.caption}
          </p>
        )}
        {post.commentCount > 0 && (
          <Link to={`/posts/${post.id}`} className="text-gray-500 text-sm mt-1 block">
            View all {post.commentCount} comments
          </Link>
        )}
        <p className="text-gray-400 text-xs mt-1 uppercase">
          {new Date(post.createdAt).toLocaleDateString()}
        </p>
      </div>
    </article>
  );
}
