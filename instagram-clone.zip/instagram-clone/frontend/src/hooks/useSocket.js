import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';

// Establishes a single authenticated Socket.IO connection for the session.
// Returns a ref to the socket instance (may be null until connected).
export function useSocket() {
  const { user } = useAuth();
  const socketRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!user || !token) return;

    const socket = io('/', { auth: { token }, path: '/socket.io' });
    socketRef.current = socket;

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [user]);

  return socketRef;
}
