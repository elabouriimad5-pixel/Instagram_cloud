/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#fdf2f8',
          500: '#e1306c',
          600: '#c13584',
        },
      },
    },
  },
  plugins: [],
};
